class Node(object):
    """
    A Node in the Graph.
    """
    __slots__ = ()
