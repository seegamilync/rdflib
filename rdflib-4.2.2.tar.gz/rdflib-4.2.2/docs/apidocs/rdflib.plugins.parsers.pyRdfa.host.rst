host Package
============

:mod:`host` Package
-------------------

.. automodule:: rdflib.plugins.parsers.pyRdfa.host
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`atom` Module
------------------

.. automodule:: rdflib.plugins.parsers.pyRdfa.host.atom
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`html5` Module
-------------------

.. automodule:: rdflib.plugins.parsers.pyRdfa.host.html5
    :members:
    :undoc-members:
    :show-inheritance:

